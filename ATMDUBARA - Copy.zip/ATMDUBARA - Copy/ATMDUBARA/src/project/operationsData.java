package project;

public class operationsData {
	private double balance;



	public operationsData(double balance) {this.balance=balance;}


	public double getBalance() {return balance;}

}
