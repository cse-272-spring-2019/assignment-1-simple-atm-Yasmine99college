package project;
public class MainFunctions {
	

		public static void main(String[] args) {
			LogicFunctions cust=new LogicFunctions(5000);
			cust.idaaa(5000);
			cust.take(3456);
			cust.idaaa(987);
			cust.take(45);
			cust.idaaa(987);
			cust.take(4567);

			cust.prnt();
			
		}

	}



