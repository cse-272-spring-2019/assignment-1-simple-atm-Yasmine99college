package project;

public class AccountData {
	private double balance;



public AccountData(double balance) {this.balance=balance;}


public double getBalance() {return balance;}



}