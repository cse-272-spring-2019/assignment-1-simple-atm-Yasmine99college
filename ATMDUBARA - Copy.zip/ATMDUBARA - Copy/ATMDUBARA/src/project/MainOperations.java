package project;



public class MainOperations {

	public static void main(String[] args) {
		Operations cust=new Operations(5000);
		cust.idaaa(1000);
		cust.take(500);
		cust.idaaa(100000);
		cust.take(500);
		cust.idaaa(1000);
		cust.take(500);

		cust.prnt();
		
	}

}
