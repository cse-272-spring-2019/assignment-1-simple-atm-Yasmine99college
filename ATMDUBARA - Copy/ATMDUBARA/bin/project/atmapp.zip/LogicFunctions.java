package project;

public class LogicFunctions {

	
	private int salary;
	//private int nhotflos;
	//private int nshilflos;
	
	public LogicFunctions(int salary) {this.salary=salary;}
	//ida3
	public int idaaa(int nhotflos) {return salary=salary+nhotflos;}
	//sa7b
	public int take (int nshilflos) {return salary=salary-nshilflos;}
	
	public int prnt() {System.out.println(salary);return salary;}
    
}



