package project;

import javafx.scene.control.TextField;

public class Operations {
	private String newSalary;
	
	private String nhotflos;
	private String nshilflos;
	Deposit_money_gui deposit;
	Withdraw_money_gui withdraw;
	TextField textFieldname=new TextField();
	String salary=textFieldname.getText();
	
	
	
	public Operations() {}
	//ida3
	public void idaaa(String nhotflos) {this.nhotflos=nhotflos;
	newSalary=salary+Integer.parseInt(nhotflos);
	salary=newSalary;}
	
  public void take (String nshilflos) {this. nshilflos=nshilflos;
  newSalary=salary-Integer.parseInt(nshilflos);
	salary=newSalary;}
	
	
	public String prnt() {System.out.println(newSalary);return newSalary;}
	
  }
	
	
	//public 

// void  Integer.parseint(newsalary)